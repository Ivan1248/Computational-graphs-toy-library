﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using Fuzzy;

namespace FuzzyShipControlSystem
{
    public abstract class FuzzySystem
    {
        protected static int dMax = 200;  // 20
        protected static int vMax = 200;  // 40
        protected static int aMax = 400;  // 40
        protected static int rMax = 120;  // 40

        private static int DomainIndex(int element, IDomain domain) => domain.IndexOf(DomainElement.Of(element));

        protected static int a(int x) => x / 20;
        protected static int ai(int x) => DomainIndex(a(x), accelDomain);
        protected static int da(double x) => (int)(x * 20);
        protected static int r(int x) => x / 15;
        protected static int ri(int x) => DomainIndex(r(x), rudderDomain);
        protected static int dr(double x) => (int)(x * 15);

        protected static int v(int x) => x / 20;
        protected static int vb(int x) => Math.Min(vMax, x) / 20;
        protected static int vi(int x) => DomainIndex(v(x), velDomain);
        protected static int dv(double x) => (int)(x * 20);
        protected static int d(int x) => x / 20;
        protected static int db(int x) => Math.Min(dMax, x) / 20;
        protected static int di(int x) => DomainIndex(d(x), velDomain);
        protected static int dd(double x) => (int)(x * 10);

        protected static IDomain
            distDomain = Domain.IntRange(d(0), d(dMax) + 1),
            velDomain = Domain.IntRange(v(0), v(vMax) + 1),
            dirDomain = Domain.IntRange(0, 1),
            rudderDomain = Domain.IntRange(r(-rMax), r(rMax) + 1),
            accelDomain = Domain.IntRange(a(-aMax), a(aMax) + 1);

        protected static IFuzzySet
            veryClose = new CalculatedFuzzySet(distDomain, LFunction(30, 50, di)),
            quiteClose = new CalculatedFuzzySet(distDomain, LambdaFunction(30, 50, 70, di)),
            close = new CalculatedFuzzySet(distDomain, LFunction(40, 60, di)),
            far = new CalculatedFuzzySet(distDomain, GammaFunction(40, 60, di)),
            notVeryClose = Operations.ZadehNot.Of(veryClose),
            notClose = far;

        protected static IFuzzySet
            verySlow = new CalculatedFuzzySet(velDomain, LFunction(40, 80, vi)),
            quiteSlow = new CalculatedFuzzySet(velDomain, LambdaFunction(60, 100, 120, vi)),
            slow = new CalculatedFuzzySet(velDomain, LFunction(100, 120, vi)),
            fast = new CalculatedFuzzySet(velDomain, GammaFunction(100, 140, vi)),
            tooFast = new CalculatedFuzzySet(velDomain, GammaFunction(140, 180, vi)),
            notFast = Operations.ZadehNot.Of(fast),
            notVerySlow = Operations.ZadehNot.Of(verySlow),
            notSlow = Operations.ZadehNot.Of(slow);

        protected static IFuzzySet
            highNegAccel = new CalculatedFuzzySet(accelDomain, LFunction(-aMax, (int)(-aMax * 0.7), ai)),
            lowNegAccel = new CalculatedFuzzySet(accelDomain, LambdaFunction((int)(-aMax * 0.8), (int)(-aMax * 0.6), (int)(-aMax * 0.4), ai)),
            zeroLikeAccel = new CalculatedFuzzySet(accelDomain, LambdaFunction(-80, 0, 80, ai)),
            lowPosAccel = new CalculatedFuzzySet(accelDomain, LambdaFunction((int)(aMax * 0.4), (int)(aMax * 0.6), (int)(aMax * 0.8), ai)),
            highPosAccel = new CalculatedFuzzySet(accelDomain, GammaFunction((int)(aMax * 0.7), aMax, ai));

        protected static IFuzzySet
            sharpLeft = new CalculatedFuzzySet(rudderDomain, GammaFunction(90, 120, ri)),
            moderateLeft = new CalculatedFuzzySet(rudderDomain, LambdaFunction(0, 45, 90, ri)),
            forward = new CalculatedFuzzySet(rudderDomain, LambdaFunction(-1, 0, 1, ri)),
            forwarish = new CalculatedFuzzySet(rudderDomain, LambdaFunction(-30, 0, 30, ri)),
            moderateRight = new CalculatedFuzzySet(rudderDomain, LambdaFunction(-90, -45, -0, ri)),
            sharpRight = new CalculatedFuzzySet(rudderDomain, LFunction(-120, -90, ri));

        protected static Func<int, double> LFunction(int a, int b, Func<int, int> conv) =>
            StandardFuzzySets.LFunction(conv(a), conv(b));
        protected static Func<int, double> LambdaFunction(int a, int b, int c, Func<int, int> conv) =>
            StandardFuzzySets.LambdaFunction(conv(a), conv(b), conv(c));
        protected static Func<int, double> GammaFunction(int a, int b, Func<int, int> conv) =>
            StandardFuzzySets.GammaFunction(conv(a), conv(b));


        public FuzzySystem(Defuzzifier defuzzify, BinaryOperation implication)
        {
            this.defuzzify = defuzzify;
            this.implication = implication ?? Math.Min;
        }

        public abstract int Infer(int L, int R, int LF, int RF, int Vel, int Dir);

        protected Rule[] rules;

        protected Defuzzifier defuzzify;

        protected BinaryOperation implication;
    }
}

﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography.X509Certificates;
using Fuzzy;

namespace FuzzyShipControlSystem
{
    public class AccelerationFuzzySystem : FuzzySystem
    {
        DomainElement LRDistance = DomainElement.Of(dMax);
        DomainElement LFRDistance = DomainElement.Of(dMax);
        DomainElement Vel = DomainElement.Of(0);

        private int trace = int.MinValue;

        public AccelerationFuzzySystem(Defuzzifier defuzzify, BinaryOperation implication = null)
            : base(defuzzify, implication)
        {
            this.defuzzify = defuzzify;
            rules = new[]
            {
                new Rule(implication, () =>
                    new[] {LRDistance, Vel},
                    new[] {veryClose , verySlow},
                    highPosAccel),

               new Rule(implication, () =>
                    new[] {LFRDistance, Vel},
                    new[] {quiteClose , notSlow},
                    lowNegAccel),
                new Rule(implication, () =>
                    new[] {LFRDistance, Vel},
                    new[] {veryClose  , notVerySlow },
                    lowNegAccel),

                new Rule(implication, () =>
                    new[] {Vel},
                    new[] {tooFast},
                    lowNegAccel),
                new Rule(implication, () =>
                    new[] {Vel    , LFRDistance},
                    new[] {notFast, notClose},
                    highPosAccel),
            };
        }

        public override int Infer(int L, int R, int LF, int RF, int Vel, int Dir)
        {
            LRDistance = DomainElement.Of(db(Math.Min(L, R)));
            LFRDistance = DomainElement.Of(db(Math.Min(LF, RF)));
            this.Vel = DomainElement.Of(vb(Vel));

            IFuzzySet[] conclusions = new IFuzzySet[rules.Length];
            for (int i = 0; i < rules.Length; i++)
                conclusions[i] = rules[i].Evaluate();
            if (trace >= 0) Trace(conclusions[trace]);
            IFuzzySet finalConclusion = Operations.MultiArg(Math.Max, conclusions);
            double result = defuzzify(finalConclusion);
            if (trace == -1) Trace(finalConclusion);
            if (!double.IsNaN(result))
                return da(result);
            ((Action)(() => Console.Beep(1200, 30))).BeginInvoke(null, null);
            return 0;
        }

        public void SetTrace(int ruleNumber = int.MinValue) => trace = ruleNumber;

        private void Trace(IFuzzySet conclusion)
        {
            Console.WriteLine(conclusion);
            var concl = defuzzify(conclusion);
            Console.WriteLine($"{concl} -> a={da(concl)}");
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography.X509Certificates;
using Fuzzy;

namespace FuzzyShipControlSystem
{
    public class SteeringFuzzySystem : FuzzySystem
    {
        DomainElement LDistance = DomainElement.Of(dMax);
        DomainElement RDistance = DomainElement.Of(dMax);
        DomainElement Vel = DomainElement.Of(0);

        public SteeringFuzzySystem(Defuzzifier defuzzify, BinaryOperation implication = null)
            : base(defuzzify, implication)
        {
            rules = new[]
            {
                new Rule(implication, () =>
                    new[] {LDistance},
                    new[] {veryClose},
                    sharpRight),
                new Rule(implication, () =>
                    new[] {LDistance},
                    new[] {quiteClose},
                    moderateRight),

                new Rule(implication, () =>
                    new[] {RDistance},
                    new[] {veryClose},
                    sharpLeft),
                new Rule(implication, () =>
                    new[] {RDistance},
                    new[] {quiteClose},
                    moderateLeft),

                new Rule(implication, () =>
                    new[] {LDistance, RDistance},
                    new[] {notClose , notClose},
                    forwarish),
            };
        }

        public override int Infer(int L, int R, int LF, int RF, int Vel, int Dir)
        {
            LDistance = DomainElement.Of(db(Math.Min(L * 2, LF)));
            RDistance = DomainElement.Of(db(Math.Min(R * 2, RF)));
            this.Vel = DomainElement.Of(vb(Vel));

            IFuzzySet[] conclusions = new IFuzzySet[rules.Length];
            for (int i = 0; i < rules.Length; i++)
                conclusions[i] = rules[i].Evaluate();
            IFuzzySet finalConclusion = Operations.MultiArg(Math.Max, conclusions);
            double result = defuzzify(finalConclusion);
            if (!double.IsNaN(result))
                return da(result);
            ((Action)(() => Console.Beep(1200, 30))).BeginInvoke(null, null);
            return 0;
        }
    }
}
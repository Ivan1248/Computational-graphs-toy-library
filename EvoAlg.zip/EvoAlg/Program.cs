﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using FDataset = EvoAlg.Dataset<EvoAlg.Vector, double>;

namespace EvoAlg
{
    static class Program
    {
        public static Random Random = new Random();

        static void Main(string[] args)
        {
            FDataset data = LoadDataset("zad4-dataset1.txt");
            GenAlg<Vector> ga = new GenerationalProportionalGenAlg<Vector>(
                errorFunc: ErrorFunc(data),
                operations: new VectorGenAlgOperationSet(mutationProbability: 0.1, mutationScale: 0.05),
                elitism: 1,
                maxIterations: int.MaxValue,
                targetError: double.Epsilon,
                populationSize: 30);
            //ga.Run();
            ga = new Eliminational3TournamentGenAlg<Vector>(
                errorFunc: ErrorFunc(data),
                operations: new VectorGenAlgOperationSet(mutationProbability: 0.1, mutationScale: 0.05),
                mortality: 1,
                maxIterations: int.MaxValue,
                targetError: double.Epsilon,
                populationSize: 100);
            ga.Run();
        }

        public static double NextNormal(this Random r) => // http://stackoverflow.com/questions/218060/random-gaussian-variables
            Math.Sqrt(-2.0 * Math.Log(r.NextDouble())) * Math.Sin(2.0 * Math.PI * r.NextDouble());

        static FDataset LoadDataset(string filePath)
        {
            FDataset dataset = new FDataset();
            using (StreamReader sr = File.OpenText(filePath))
                while (!sr.EndOfStream)
                {
                    var s = sr.ReadLine().Split('\t');
                    dataset.Add(Vector.New(double.Parse(s[0]), double.Parse(s[1])), double.Parse(s[2]));
                }
            return dataset;
        }

        static double F(double b0, double b1, double b2, double b3, double b4, double x, double y)
            => Math.Sin(b0 + b1 * x) + b2 * Math.Cos(x * (b3 + y)) * 1 / (1 + Math.Exp(Math.Pow(x - b4, 2)));

        static double F(Vector b, Vector x) =>
            F(b[0], b[1], b[2], b[3], b[4], x[0], x[1]);

        static FitnessFunc<Vector> ErrorFunc(FDataset data) =>
            parameters => data.Average(dp => Math.Pow(F(parameters, dp.x) - dp.y, 2));

        class VectorGenAlgOperationSet : IGenAlgOperationSet<Vector>
        {
            private readonly double mutationProbability, mutationScale;

            public VectorGenAlgOperationSet(double mutationProbability, double mutationScale)
            {
                this.mutationProbability = mutationProbability;
                this.mutationScale = mutationScale;
            }

            public Vector Generate() =>
                Vector.New(Random.NextDouble() * 8 - 4, Random.NextDouble() * 8 - 4, Random.NextDouble() * 8 - 4,
                    Random.NextDouble() * 8 - 4, Random.NextDouble() * 8 - 4);

            public Vector Mutate(Vector x)
            {
                x = x.Copy();
                for (int i = 0; i < x.Dimension; i++)
                    if (Random.NextDouble() < mutationProbability)
                        x[i] += Random.NextNormal() * mutationScale;
                return x;
            }

            public Vector Crossover(Vector[] x)
            {
                var r = x[0].Copy();
                for (int i = 1; i < x.Length; i++)
                    r.Add(x[i]);
                return r.DivBy(x.Length);
            }
        }
    }
}

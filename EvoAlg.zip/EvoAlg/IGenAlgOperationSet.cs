﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EvoAlg
{
    public interface IGenAlgOperationSet<T>
    {
        T Mutate(T c);
        T Crossover(params T[] p);
        T Generate();
    }
}

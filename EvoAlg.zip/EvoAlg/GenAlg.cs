﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace EvoAlg
{
    public delegate double FitnessFunc<T>(T c);

    public struct Individual<T>
    {
        public T Value;
        public double Fitness;
        public override string ToString() => $"({Value}, {Fitness})";
    }

    public abstract class GenAlg<T>
    {
        protected readonly FitnessFunc<T> Error;

        private readonly IGenAlgOperationSet<T> operations;

        private int iteration = 0;

        private readonly int maxIterations;
        private readonly double targetFitness;
         
        protected Individual<T>[] population;

        protected readonly Random Random = new Random();

        public List<Individual<T>> Population => new List<Individual<T>>(population);
        public int Iteration => iteration;

        public GenAlg(FitnessFunc<T> errorFunc, IGenAlgOperationSet<T> operations, int populationSize = 20,
            int maxIterations = 100000, double targetError = 1e-15)
        {
            this.Error = errorFunc;
            this.operations = operations;

            var population = new Individual<T>[populationSize];
            for (int i = 0; i < populationSize; i++)
            {
                var chromosome = operations.Generate();
                population[i] = new Individual<T> { Value = chromosome, Fitness = 1 / errorFunc(chromosome) };
            }
            this.population = population;
            this.maxIterations = maxIterations;
            this.targetFitness = 1/targetError;
        }

        public Individual<T> Run()
        {
            for (int i = 0; i < maxIterations; i++)
            {
                RunIteration();
                if (population[0].Fitness > targetFitness) break;
            }
            return population[0];
        }

        public Individual<T> RunIteration()
        {
            iteration++;
            var previousBestFitness = population[0].Fitness;
            SelectNextPopulation();
            Array.Sort(population, (a, b) => a.Fitness > b.Fitness ? -1 : 1);
            if (population[0].Fitness > previousBestFitness)
            {
                Console.WriteLine($"Iteration: {iteration}:\n" +
                                  $"  error: {1 / population[0].Fitness}\n" +
                                  $"  value: {population[0].Value}");
            }
            return population[0];
        }

        protected abstract void SelectNextPopulation();

        protected T Mutate(T x) => operations.Mutate(x);

        protected T Crossover(params T[] x) => operations.Crossover(x);
    }
}

﻿using System;
using System.Globalization;
using System.Threading;

namespace LinAlg
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
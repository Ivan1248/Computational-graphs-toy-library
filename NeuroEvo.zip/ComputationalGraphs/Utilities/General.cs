﻿namespace ComputationalGraphs.Utilities
{
    public class General
    {
        public static void Swap<T>(ref T a, ref T b)
        {
            T temp = a;
            a = b;
            b = temp;
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using ComputationalGraphs;
using EvoAlg;
using LinAlg;

namespace NeuroEvo
{
    public static class NeuroEvo
    {
        public static Node CentroidLayer(this Node x, int dimension)
        {
            x = x.Repeat(dimension).Add().Mul().Abs();
            var sums = from i in Enumerable.Range(0, dimension) let k = i * 2 select x.Slice(k, k + 2).ReduceSum();
            return 1 / (1 + Nodes.Concat(sums));
        }

        public static Node NeuronLayer(this Node x, int dimension) => x.WeightedSums(dimension, true).Logistic();

        public static Node NeuralNetwork(this Node input, int centroidsDimension, params int[] neuronsDimensions)
        {
            input = input.CentroidLayer(centroidsDimension);
            return neuronsDimensions.Aggregate(input, (current, d) => current.NeuronLayer(d));
        }

        private static void Main(string[] args)
        {
            InputNode inputNode = Nodes.Input(2), labelNode = Nodes.Input(3);
            var outputNode = inputNode.NeuralNetwork(8, 3);
            var lossNode = outputNode.SquaredLoss(labelNode);
            var nodes = outputNode.CollectPreceedingNodes();
            var trainer = new Trainer(inputNode, labelNode, lossNode, new GradientDescentOptimizer(0), nodes);

            Data.Load("zad7-dataset.txt", out var X, out var Y);
            trainer.SetData(X, Y);

            var generator = ListGenOps.Mutator(GenOps.VectorNormalReplacementMutator(1, 1));
            var mutator = ListGenOps.CombinedMutator(
                0.9,
                ListGenOps.Mutator(GenOps.VectorNormalMutator(0.02, 0.3)),
                ListGenOps.Mutator(GenOps.VectorNormalReplacementMutator(0.08, 1))
            );

            var ga = new EliminationalTournamentGenAlg<IList<Vector>>(
                errorFunc: p => { outputNode.CollectPreceedingNodes().SetParameters(p); return trainer.GetError(); },
                generate: () => generator(nodes.GetParameters()),
                mutate: mutator,
                crossover: ListGenOps.Crossoverator(GenOps.VectorSegmentedCrossoverator(0.12)),
                populationSize: 8,
                maxEvaluations: 400000,
                maxIterations: 400000,
                targetError: 1e-7,
                printProgress: true,
                tournamentSize: 3
            );
            nodes.SetParameters(ga.Run());

            Console.WriteLine("\nParametri od zadnjeg prema prvom sloju:");
            foreach (var p in nodes.GetParameters())
                Console.WriteLine(p);

            Console.WriteLine("\nRezultati:");
            Vector GetOutput(Vector x) { inputNode.Set(x); return outputNode.Output; }
            var Yp = (from x in X select GetOutput(x)).ToList();
            var Ypd = (from y in Yp select Vector.OneHot(y.ArgMax(), y.Dimension)).ToList();
            var R = Ypd.Zip(Y, (h, t) => h.ArgMax() == t.ArgMax());
            Console.WriteLine($"{"ulaz",14} {"labela",10} {"predikc.",10} {"ispravno",10}");
            for (var i = 0; i < Yp.Count; i++)
                Console.WriteLine($"{X[i].ToString(3),14} {Y[i],10} {Ypd[i],10} {(Ypd[i].ArgMax() == Y[i].ArgMax() ? '+' : '-'),10}");

            Console.WriteLine($"\nTočnost: {R.Count(r => r)}/{Y.Count}");
        }
    }
}